package myproject;

public class Exercicio_2 {
	
	public static void main(String[] args) {
		int soma = 0;
		for(int i = 0; i <= 1000; i++){
			soma = soma + i;
		}

		System.out.println(soma);
	}
}
