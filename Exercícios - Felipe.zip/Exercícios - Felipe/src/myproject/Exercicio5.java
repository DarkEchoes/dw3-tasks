package meuprojeto;

public class Exercicio_5 {
	public static void main(String[] args) {
		int fat = 1;
		for(int i = 1; i <= 40; i++){
			while(i >= 2){
				fat = fat * i;
				break;
			}

			System.out.println(fat);
		}
	}
	// como s�o muitos c�lculos, demoram para serem resolvidos
}
