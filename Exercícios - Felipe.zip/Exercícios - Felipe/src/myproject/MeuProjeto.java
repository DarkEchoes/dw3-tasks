
package myproject;


public class Meu_Projeto {


	public static void main(String[] args) {
		System.out.println("Imprimir mensagem diferente ");
		System.out.println("Imprimir mensagem dois ");
		System.out.println("Imprimir mensagem \n  diferente ");
		
	}

}

// pergunta 1:
////// Basta alterar o nome da public class principal

