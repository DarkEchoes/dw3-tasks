package myproject;

public class Balanco_Tri {

	public static void main(String[] args) {
		int gastosJan = 15000;
		int gastosFev = 23000;
		int gastosMar = 17000;
		int gastosTri = gastosJan + gastosFev + gastosMar;
		double mediaMensal = (gastosJan + gastosFev + gastosMar) / 3;
		
		System.out.println(gastosTri);
		System.out.println("M�dia mensal =  " + mediaMensal);
		
	}

}
